// 页面加载时初始化
window.onload = initializeHistory;
document.getElementById("deleteAll").onclick = removeAllArticles;
document.getElementById("add").onclick = saveNewArticle;
// 初始化历史记录显示
function initializeHistory() {
    displayCurrentTabUrl();
    updateArticleList();
}
// 保存新的文章
function saveNewArticle() {
    let inputUrl = document.getElementById("url").value;
    let inputTitle = document.getElementById("name").value;
    if (!inputUrl || !inputTitle) {
        alert("网址或标题不能为空！");
        return;
    }
    let newArticle = { url: inputUrl, title: inputTitle };
    appendArticle(newArticle);
    clearInputFields();
    updateArticleList();
}
// 清除所有文章记录
function removeAllArticles() {
    if (confirm("确定要清空所有记录吗？")) {
        localStorage.removeItem("articles");
        updateArticleList();
    }
}
// 更新文章列表显示
function updateArticleList() {
    let articles = getStoredArticles();
    let displayArea = document.getElementById("historyContent");
    displayArea.innerHTML = articles.map((article, index) => createArticleHtml(article, index)).join("");

    attachDeleteHandlers();
}
// 创建文章的HTML表示
function createArticleHtml(article, index) {
    return `<div class="contentUrl">
                <a href="${article.url}" target="_blank"><h3>${article.title}</h3></a>
                <button class="btn" id="delete-${index}">删除</button>
            </div>`;
}
// 附加删除事件处理器
function attachDeleteHandlers() {
    document.querySelectorAll(".btn").forEach(button => {
        if (button.id.startsWith("delete-")) {
            button.onclick = () => removeArticleById(button.id);
        }
    });
}
// 根据ID删除文章
function removeArticleById(buttonId) {
    let index = parseInt(buttonId.split("-")[1]);
    if (isNaN(index)) return;
    if (confirm("确定删除该记录吗？")) {
        let articles = getStoredArticles();
        articles.splice(index, 1);
        localStorage.setItem("articles", JSON.stringify(articles));
        updateArticleList();
    }
}
// 添加文章到存储
function appendArticle(article) {
    let articles = getStoredArticles();
    articles.unshift(article);
    localStorage.setItem("articles", JSON.stringify(articles));
}
// 获取存储的文章
function getStoredArticles() {
    let articles = localStorage.getItem("articles");
    return articles ? JSON.parse(articles) : [];
}
// 清除输入字段
function clearInputFields() {
    document.getElementById("url").value = "";
    document.getElementById("name").value = "";
}
// 显示当前标签的URL
function displayCurrentTabUrl() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        document.getElementById("url").value = tabs[0].url;
    });
}
