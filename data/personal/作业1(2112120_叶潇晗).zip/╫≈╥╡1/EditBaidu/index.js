alert("百度已被修改！")
function setBg(){
  document.body.setAttribute("style","background-color: blue");
}

function delContent(){
  document.getElementsByClassName("hot-news-wrapper")[0].remove();
}
// 延迟三秒后，改变百度网站
(function() {
    setTimeout(setBg,3000);
    setTimeout(delContent,3000);
})();