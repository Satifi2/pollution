document.body.style.backgroundColor = "#1F1F1F";
document.body.style.color = "#fff";
//document.querySelectorAll('body, body *').forEach(element => {
//  element.style.color = '#fff';
//});